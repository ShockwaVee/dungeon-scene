3d Polygon Model of Ancient Scroll, Book, Feather and Candle with Candle Holder
for animations, visualizations & games.

Features:

Geometry - Polygons , Faces = 5674,   Vertices = 6250

Available formats:  Autodesk FBX, Maya binary .mb and OBJ

Realistic 3d Model with Clean Topology.

UV Mapped - 1024x1024 JPG Textures

Diffuse,Normal and Specular Maps

Rendered with Mental Ray and Maya Software 2011. 

Can be used Commercially with credits.

ANIMATED HEAVEN










 